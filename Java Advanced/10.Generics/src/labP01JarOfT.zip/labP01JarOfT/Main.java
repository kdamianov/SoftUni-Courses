package labP01JarOfT;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Jar<String> stringJar = new Jar<>();

        stringJar.add("Drago");
        stringJar.add("Sulyo");
    }
}
