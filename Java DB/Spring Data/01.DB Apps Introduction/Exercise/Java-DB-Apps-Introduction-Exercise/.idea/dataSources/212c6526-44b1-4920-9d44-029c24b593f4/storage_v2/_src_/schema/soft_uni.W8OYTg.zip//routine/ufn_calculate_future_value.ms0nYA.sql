create
    definer = root@localhost function ufn_calculate_future_value(init_sum decimal(19, 4),
                                                                 yearly_interest_rate decimal(19, 4),
                                                                 years int) returns decimal(19, 4) deterministic
BEGIN
RETURN 
	init_sum * POW((1 + yearly_interest_rate), years);
END;

