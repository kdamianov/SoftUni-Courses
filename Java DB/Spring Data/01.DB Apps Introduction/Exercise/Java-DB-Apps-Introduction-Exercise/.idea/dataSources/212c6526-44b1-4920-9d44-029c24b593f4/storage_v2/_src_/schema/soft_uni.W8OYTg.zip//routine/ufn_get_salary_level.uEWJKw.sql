create
    definer = root@localhost function ufn_get_salary_level(salary decimal(50, 4)) returns varchar(10) deterministic
BEGIN
	DECLARE salary_level varchar(10);
    set salary_level := (
    case
    when salary < 30000 then 'Low'
    when salary <= 50000 then 'Average'
    when salary > 50000 then 'High'
    end);
    return salary_level;
END;

