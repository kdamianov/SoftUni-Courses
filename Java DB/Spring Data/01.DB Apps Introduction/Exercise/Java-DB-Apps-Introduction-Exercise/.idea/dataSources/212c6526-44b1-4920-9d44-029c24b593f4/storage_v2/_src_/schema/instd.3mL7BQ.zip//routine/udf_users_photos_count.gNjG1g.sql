create
    definer = root@localhost function udf_users_photos_count(username varchar(30)) returns int deterministic
BEGIN
return (select count(up.photo_id) from users as u
left join users_photos as up on up.user_id = u.id
where u.username = username
group by u.id);
END;

