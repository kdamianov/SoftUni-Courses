create
    definer = root@localhost function udf_courses_by_client(phone_num varchar(20)) returns int deterministic
begin
return (
select count(co.client_id) from clients as cl
left join courses as co on co.client_id = cl.id
where cl.phone_number = phone_num
);
end;

