create
    definer = root@localhost procedure usp_get_holders_with_balance_higher_than(IN money_param decimal(20, 4))
BEGIN
	SELECT 
		ah.first_name, ah.last_name
	FROM
		account_holders AS ah
			LEFT JOIN
		accounts AS a ON ah.id = a.account_holder_id
	GROUP BY a.account_holder_id
	HAVING SUM(a.balance) > money_param
	ORDER BY ah.id;
	END;

