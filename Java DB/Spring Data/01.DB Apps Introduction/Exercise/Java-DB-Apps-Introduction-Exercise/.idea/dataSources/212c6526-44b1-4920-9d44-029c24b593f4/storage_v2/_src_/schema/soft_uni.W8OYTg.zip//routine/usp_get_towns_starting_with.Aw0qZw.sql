create
    definer = root@localhost procedure usp_get_towns_starting_with(IN argument varchar(50))
BEGIN
	SELECT 
		t.name
	FROM
		towns AS t
	WHERE
		 t.name like concat(argument, '%')
	ORDER BY t.name;
END;

