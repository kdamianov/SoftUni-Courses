create
    definer = root@localhost procedure usp_calculate_future_value_for_account(IN account_id int, IN interest_rate decimal(19, 4))
BEGIN
	select ah.id as 'account_id',
		ah.first_name,
		ah.last_name,
        a.balance as 'current_balance',
        ufn_calculate_future_value(a.balance, interest_rate, 5) as 'balance_in_5_years'
    from accounts as a
    join account_holders as ah on a.account_holder_id = ah.id
    where a.id = account_id;
END;

