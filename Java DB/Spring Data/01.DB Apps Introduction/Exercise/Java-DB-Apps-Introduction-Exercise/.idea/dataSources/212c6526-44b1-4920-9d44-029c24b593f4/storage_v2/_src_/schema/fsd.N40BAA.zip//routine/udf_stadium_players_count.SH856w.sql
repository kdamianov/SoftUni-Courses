create
    definer = root@localhost function udf_stadium_players_count(stadium_name varchar(30)) returns int deterministic
BEGIN
	RETURN (select count(p.first_name) from stadiums as s
			left join teams as t on t.stadium_id = s.id
			left join players as p on p.team_id = t.id
			where s.name = stadium_name
			group by s.id);
END;

